
package carrentalsystem;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class reportGenderPage{
    
    
    public JFrame getJFrame(){
        return frame;
    }
    private JFrame frame;
    private JPanel headerPanel;
    private JLabel headerLabel, analysis;
    private Font titleFont;
    
    public reportGenderPage(){
        frame = new JFrame();
        frame.setSize(1000,650);
        frame.setLocation(500,300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        titleFont = new Font(null, Font.BOLD, 24);        
        headerPanel = new JPanel();
        headerPanel.setBackground(Color.GRAY);
        headerLabel = new JLabel("*Car Rental System*");
        headerLabel.setFont(titleFont);
        headerLabel.setForeground(Color.white);
        headerPanel.add(headerLabel);
        frame.add(headerPanel, BorderLayout.NORTH);
        
        int size = InformationIO.allCustomers.size();      
        int male = 0, female = 0;
        for(int i=0; i<size; i++){
            Customer c = InformationIO.allCustomers.get(i);
            if (c.getGender().equals("Male")){
                male = male + 1;
            } else if (c.getGender().equals("Female")){
                female = female + 1;
            }
        }
        
        // Label
        analysis = new JLabel();
        analysis.setBounds(100, 350, 500,25);
        analysis.setFont(new Font("MV Boli",Font.BOLD,14));
        analysis.setText("There are " + male + " males and " + female + " females");
        
        frame.add(analysis);
        frame.setVisible(true);
        
        
        
        
    }
    
    
    
}
