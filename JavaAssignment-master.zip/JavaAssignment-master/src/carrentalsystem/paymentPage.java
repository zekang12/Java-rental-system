package carrentalsystem;

import static carrentalsystem.CarRentalSystem.loginBooking;
import static carrentalsystem.CarRentalSystem.loginUser;
import static carrentalsystem.InformationIO.allPayments;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;



public class paymentPage implements ActionListener{
    public void actionPerformed (ActionEvent e){
        try{
            if(e.getSource() == AmountField){
                String input = AmountField.getText();
                AmountField.setText(""); // make the text empty
                double payment = Double.parseDouble(input);
                if(payment<1){
                    throw new Exception();
                }
                    //payment less than amount
                    if(payment < amount){
                     JOptionPane.showMessageDialog(frame,"Please make full payment");  
                    }
                        //payment more than amount
                        if(payment > amount){
                          JOptionPane.showMessageDialog(frame,"please enter exact amount");  
                        }
                            if(payment == amount){
                                // payment info write                        
                                //generate ID
                                String fullId = InformationIO.autogeneratePaymentID();

                                //generate date
                                Date thisDate = new Date();
                                SimpleDateFormat dateForm = new SimpleDateFormat("dd/MM/yyyy");
                                String paydate = dateForm.format(thisDate);

                                //find booking id                       
                                int size = CarRentalSystem.loginUser.getMyBooking().size();
                                String bookid = CarRentalSystem.loginUser.getMyBooking().get(size-1).getBookingID();


                                //set status to completed
                                CarRentalSystem.loginUser.getMyBooking().get(size-1).setStatus("Completed");

                                //check booking ID
                                Booking foundBooking = InformationIO.checkBookingID(bookid);                        
                                if(foundBooking != null){
                                    CarRentalSystem.loginBooking = foundBooking;
                                    String bookingID = foundBooking.getBookingID();
                                }

                                //rating
                                String rate = JOptionPane.showInputDialog("please enter your rating between 1-5 :");
                                int rating = Integer.parseInt(rate);
                                //rating validation
                                if(rating > 5 || rating < 0){
                                    JOptionPane.showMessageDialog(frame,"Rate us in between 1-5!! please try again");
                                }else{
                                    String id = fullId;
                                    String paymentDate = paydate;
                                    double totpayment = amount;

                                    Payment py = new Payment(id,paymentDate,loginBooking,loginUser,totpayment,rating); 
                                    allPayments.add(py);
                                    CarRentalSystem.loginUser.getMyPayment().add(py);
                                    CarRentalSystem.loginCar.setStatus("Not Available");
                                    InformationIO.writeToBookingFile();
                                    InformationIO.writeToPaymentFile();

                                    JOptionPane.showMessageDialog(frame,"full payment received, thank you!");
                                    BookingDetail bd = new BookingDetail();
                                    bd.setVisible(true);

                                    frame.dispose();
                            }  
                                }                       
                }else if(e.getSource() == backButton){                   
                    BookingDetail bd = new BookingDetail();
                    bd.setVisible(true);
        
                    frame.dispose();
                }else{
                    throw new Exception();
                }

                        
//            if(payment>=amount){
//                JOptionPane.showMessageDialog(x, "Thank you for your payment and the change is RM"+(payment-amount)+"!");
//                Sample.loginUser = null;
//                x.setVisible(false);
//                Sample.page1.getJFrame().setVisible(true);
//            } else{
//                amount = amount-payment;
//                JOptionPane.showMessageDialog(x, "You need to make full payment!");
//                y.setText("You need to pay RM"+amount+".");
//            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(frame, "Invalid input!");
        }
    }
    
//    public Label getLabel(){    // label is object, so no need setter 
//        return y;               //since the changes will be mde automatically
//    }
    public void setAmount(double x){
        amount = x;
    }
    
    
    public JFrame getJFrame(){
       return frame;
    }
    private JFrame frame;
    private JPanel panel, headerPanel, buttonPanel;
    private JLabel label, headerLabel;
    private Font titleFont, subtitleFont;
    private JTextField AmountField;
    private JButton backButton;
    
    
    private double amount;
    public paymentPage(){
      int size = CarRentalSystem.loginUser.getMyBooking().size();
      double charge = CarRentalSystem.loginUser.getMyBooking().get(size-1).getTotalRental();
        
        frame = new JFrame("Payment Page");
        frame.setSize(300,200);
        frame.setLocation(700, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        titleFont = new Font(null, Font.BOLD, 24);
        subtitleFont = new Font(null, Font.BOLD, 16);
        
        // Panel
        panel = new JPanel();
        headerPanel = new JPanel();
        buttonPanel = new JPanel();              
        
        // hearder       
        headerPanel.setBackground(Color.GRAY);
        headerLabel = new JLabel("*Payment Page*");
        headerLabel.setFont(titleFont);
        headerLabel.setForeground(Color.white);
        headerPanel.add(headerLabel);
        
        
        // Label
        label = new JLabel("you need pay RM"+charge, JLabel.CENTER);
        label.setFont(subtitleFont);
        panel.add(label);
        
        // Text Field
        AmountField = new JTextField(20);
        AmountField.addActionListener(this);
        panel.add(AmountField);
        
        frame.add(panel, BorderLayout.CENTER);
        
        // Button
        backButton = new JButton("Exit");
        backButton.addActionListener(this);
        buttonPanel.add(backButton);
        
        frame.add(headerPanel, BorderLayout.NORTH);
        frame.add(buttonPanel, BorderLayout.SOUTH);
        
        
        
        frame.setVisible(true);
    }
    
}