package carrentalsystem;

import static carrentalsystem.CarRentalSystem.loginCar;
import static carrentalsystem.CarRentalSystem.loginUser;
import static carrentalsystem.InformationIO.allBookings;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class BookingPage implements ActionListener{  
    public void actionPerformed(ActionEvent e){
        if (e.getSource() == resetButton){
            rentDateField.setText(null);
            returnDateField.setText(null);
            carIDField.setText(null);
                    
        } else if (e.getSource() == bookButton){  
            try{
                String id = BookingIDField.getText();
                String rentday = rentDateField.getText();
                String returnday = returnDateField.getText();
                String carid = carIDField.getText();
                String status = "Pending";
                
                
                //car found and status
                Car foundcar = InformationIO.checkCarID(carid);
                if(foundcar != null && foundcar.getStatus().equals("Available")){
                     CarRentalSystem.loginCar = foundcar;
                     double price = foundcar.getRentPrice();         
                    //date
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/uuuu");           
                    LocalDate date1 = LocalDate.parse(rentday,formatter);
                    LocalDate date2 = LocalDate.parse(returnday,formatter);
                    long daysBetween = ChronoUnit.DAYS.between(date1, date2);
                    int num = Math.toIntExact(daysBetween);

                    if(daysBetween > -1){
                        double totRent = num * price;

                        Booking bk = new Booking(id,rentday,returnday,status,totRent,loginUser,loginCar);
                        allBookings.add(bk);
                        CarRentalSystem.loginUser.getMyBooking().add(bk);
                        CarRentalSystem.loginCar.setStatus("Booked");
                        
                        InformationIO.writeToBookingFile();
                        InformationIO.writeToCarFile();
                        JOptionPane.showMessageDialog(frame, "Booking Successful!!!");

                        CusHomePage home_page = new CusHomePage();        
                        home_page.setVisible(true);
                        frame.setVisible(false);

                    }else{
                         JOptionPane.showMessageDialog(frame, "Return Date must be late than Rent Date");

                    }                   
                }else{
                     JOptionPane.showMessageDialog(frame, "Car is not available\nplease try again!!!");
                }
            }catch(Exception ex){
                JOptionPane.showMessageDialog(frame,"error date, please try again");
            }  
        
            
            
        } else if (e.getSource () == exitButton){
                   
            CusHomePage home_page = new CusHomePage();        
            home_page.setVisible(true);
            frame.setVisible(false);
   
        } 
    }
    
    public JFrame getJFrame(){
        return frame;
    }
    
    
    private JFrame frame;
    private JPanel upperPanel, input_Panel, BookingID_Panel, 
            RentDate_Panel, ReturnDate_Panel, CarID_Panel, button_Panel, 
            lowerPanel, headerPanel;
    private JLabel BookingIDLabel, rentDateLabel, returnDateLabel, carIDLabel, 
            headerLabel;
    private JButton resetButton, bookButton, exitButton;
    private JTextField BookingIDField, rentDateField, returnDateField, carIDField;
    private DefaultTableModel tableModel;
    private JTable table;
    private JScrollPane sp;
    private Font titleFont, subtitleFont;


    public BookingPage(){    
        frame = new JFrame("Booking Page");
        frame.setSize(600,400);
        frame.setLocation(700,300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        
        frame.setLayout(new GridLayout(2,1));
        
        titleFont = new Font(null, Font.BOLD, 24);
        subtitleFont = new Font(null, Font.PLAIN, 14);
        
        // Panel
        upperPanel = new JPanel();
        upperPanel.setLayout(new BorderLayout());
        input_Panel = new JPanel();
        input_Panel.setLayout(new GridLayout(2,4));
        BookingID_Panel = new JPanel();
        RentDate_Panel = new JPanel();
        ReturnDate_Panel = new JPanel();
        CarID_Panel = new JPanel();
        button_Panel = new JPanel();
        lowerPanel = new JPanel(new GridLayout());
        
        // hearder
        headerPanel = new JPanel();
        headerPanel.setBackground(Color.GRAY);
        headerLabel = new JLabel("*Booking Page*");
        headerLabel.setFont(titleFont);
        headerLabel.setForeground(Color.white);
        headerPanel.add(headerLabel);
        upperPanel.add(headerPanel, BorderLayout.NORTH);
        

        // Label
        BookingIDLabel = new JLabel("BookingID", JLabel.CENTER);
        rentDateLabel = new JLabel("RentDate", JLabel.CENTER);
        returnDateLabel = new JLabel("ReturnDate", JLabel.CENTER);
        carIDLabel = new JLabel("CarID", JLabel.CENTER);
        
        
        BookingIDLabel.setFont(subtitleFont);
        rentDateLabel.setFont(subtitleFont);
        returnDateLabel.setFont(subtitleFont);
        carIDLabel.setFont(subtitleFont);
        
        input_Panel.add(BookingIDLabel);
        input_Panel.add(rentDateLabel);
        input_Panel.add(returnDateLabel);
        input_Panel.add(carIDLabel);
        
        // Text Field
        BookingIDField = new JTextField(10);
        rentDateField = new JTextField(10);
        returnDateField = new JTextField(10);
        carIDField = new JTextField(10);
        
        // auto generate ID and cant edit
        String fullId = InformationIO.autogenerateBookingID();
        BookingIDField.setText(fullId);        
        BookingIDField.setEditable(false);   
        
        BookingID_Panel.add(BookingIDField);
        RentDate_Panel.add(rentDateField);
        ReturnDate_Panel.add(returnDateField);
        CarID_Panel.add(carIDField);
        
        
        input_Panel.add(BookingID_Panel);
        input_Panel.add(RentDate_Panel);
        input_Panel.add(ReturnDate_Panel);
        input_Panel.add(CarID_Panel);
        
        // Button
        resetButton = new JButton("Reset");
        bookButton = new JButton("Book");
        exitButton = new JButton("Exit");
        
        resetButton.addActionListener(this);
        bookButton.addActionListener(this);
        exitButton.addActionListener(this);
        
        button_Panel.add(resetButton);
        button_Panel.add(bookButton);
        button_Panel.add(exitButton);
        
        // Add input and button to upper panel
        upperPanel.add(button_Panel, BorderLayout.SOUTH);      
        upperPanel.add(input_Panel, BorderLayout.CENTER);
        frame.add(upperPanel);
        
        
        // Table
        int size = InformationIO.allCars.size();
        
        String[][] data = new String[size][5];
        for(int i=0; i<size; i++){
            Car c = InformationIO.allCars.get(i);
            data[i][0] = c.getCarID();
            data[i][1] = c.getModel();
            data[i][2] = c.getStatus();
            data[i][3] = ""+c.getManufactureYear();
            data[i][4] = ""+c.getRentPrice();
        }
        String[] columnNames = {"CarID", "Model", "Status", "ManufactureYear", "RentPrice" };
        tableModel = new DefaultTableModel(data, columnNames);
        table = new JTable(tableModel);
        table.setEnabled(false);
        sp = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, 
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        lowerPanel.add(sp);
        frame.add(lowerPanel);
        
        frame.setVisible(true);
        
    }
}


