package carrentalsystem;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class InformationIO {
    public static ArrayList<Customer> allCustomers = new ArrayList<Customer>();         //customer array list   
    public static ArrayList<Booking> allBookings = new ArrayList<Booking>();
    public static ArrayList<Car> allCars = new ArrayList<Car>();
    public static ArrayList<Admin> allAdmins = new ArrayList<Admin>();
    public static ArrayList<Payment> allPayments = new ArrayList<Payment>();
    
    public static void readFromCusFile(){      //why static because only 1 txt file/database
        try{
            // Read customer file
            Scanner s = new Scanner(new File("customerInfo.txt"));
            while(s.hasNext()){
               String a = s.nextLine(); //cusID
               String b = s.nextLine(); //username
               String c = s.nextLine(); //gender
               String d = s.nextLine(); //email
               String e = s.nextLine(); //address
               int f = Integer.parseInt(s.nextLine()); //phoneNum
               String g = s.nextLine(); //password
               s.nextLine();
               allCustomers.add(new Customer(a,b,Sex.valueOf(c),d,e,f,g));
            }                    
        }catch(Exception e){
            System.out.println("Failed to read customer file!!");
        }
    }
    
    public static void readFromAdminFile(){
        try{
            // Read Admin file
            Scanner s = new Scanner(new File("adminInfo.txt"));
            while(s.hasNext()){
               String a = s.nextLine(); //cusID
               String b = s.nextLine(); //username
               String c = s.nextLine(); //password
               s.nextLine();
               allAdmins.add(new Admin(a,b,c)); 
            }  
        } catch(Exception e){
            System.out.println("Failed to read admin file!!");
        }
    }
    
    public static void readFromCarFile(){
        try{
            //Read Car file
            Scanner s = new Scanner(new File("CarInfo.txt"));
            while(s.hasNext()){
                String a = s.nextLine(); //CarID
                String b = s.nextLine(); //Model
                String c = s.nextLine(); //Status
                int d = Integer.parseInt(s.nextLine()); //ManufactureYear
                double e = Double.parseDouble(s.nextLine()); //RentPrice               
                s.nextLine();
                Car z = new Car(a,b,c,d,e);
                allCars.add(z);
            }
        } catch(Exception e){
            System.out.println("Failed to read admin file!!");
        }
    }
    
    public static void readFromBookingFile(){
        try{
            // Read booking file
            Scanner s = new Scanner(new File("BookingInfo.txt"));
            while(s.hasNext()){
                String a = s.nextLine();  //bookingID
                String b = s.nextLine();  //rentDate
                String c = s.nextLine();  //returnDate
                String d = s.nextLine();  //status
                double e = Double.parseDouble(s.nextLine());  //totalRental               
                Customer f = checkAccID(s.nextLine());  // CustomerID
                Car g = checkCarID(s.nextLine());  // CarID                 
                s.nextLine();
                Booking x = new Booking(a,b,c,d,e,f,g);
                allBookings.add(x);
                f.getMyBooking().add(x);
            } 
        } catch(Exception e){
            System.out.println("Failed to read admin file!!");
        }        
    }
    
        public static void readFromPaymentFile(){
        try{
            // Read booking file
            Scanner s = new Scanner(new File("paymentInfo.txt"));
            while(s.hasNext()){
                String a = s.nextLine();  //paymentID
                String b = s.nextLine();  //paymentDate
                Booking c = checkBookingID(s.nextLine());  //bookingID
                Customer d = checkAccID(s.nextLine());    // customer ID
                double e = Double.parseDouble(s.nextLine()); // totalPayment
                int f = Integer.parseInt(s.nextLine()); //rating
                 
                s.nextLine();
                Payment x = new Payment(a,b,c,d,e,f);
                allPayments.add(x);
                d.getMyPayment().add(x);
            } 
        } catch(Exception e){
            System.out.println("Failed to read payment file!!");
        }        
    }
    
    
    public static void writeToCusFile(){
        try{
            //Write to customerInfo file
            PrintWriter x = new PrintWriter("customerInfo.txt"); 
            for(Customer c : allCustomers){
                x.println(c.getAccID());
                x.println(c.getUsername());
                x.println(c.getGender());
                x.println(c.getEmail());
                x.println(c.getAddress());
                x.println(c.getPhoneNum());
                x.println(c.getPassword());
                x.println();
            }
            x.close();         
        }catch(Exception e){
            System.out.println("Failed to write customer file!!");
        }
    }
    
    public static void writeToBookingFile(){
        try{
            //Write to BookingInfo File
            PrintWriter x = new PrintWriter("BookingInfo.txt");
            for(Booking b : allBookings ){
                x.println(b.getBookingID());    
                x.println(b.getRentDate());
                x.println(b.getReturnDate());
                x.println(b.getStatus());
                x.println(b.getTotalRental());                
                x.println(b.getOwner().getAccID());                
                x.println(b.getCar().getCarID());    
                x.println();
            }
            x.close();
        }catch(Exception e){
            System.out.println("Failed to write booking file!!");
            e.printStackTrace();
        }
    }
    
    
    public static void writeToCarFile(){
        try{
            //Write to carInfo File
            PrintWriter x = new PrintWriter("CarInfo.txt");
            for (Car c: allCars){
                x.println(c.getCarID());
                x.println(c.getModel());
                x.println(c.getStatus());
                x.println(c.getManufactureYear());
                x.println(c.getRentPrice());
                x.println();       
            }
            x.close();
        }catch(Exception e){
            System.out.println("Failed to write car file!!");
        }
    }
    
    public static void writeToAdminFile(){
        try{
            //Write to adminInfo File
            PrintWriter x = new PrintWriter("adminInfo.txt");
            for (Admin a: allAdmins){
                x.println(a.getAccID());
                x.println(a.getUsername());
                x.println(a.getPassword());
                x.println();       
            }
            x.close();
        }catch(Exception e){
            System.out.println("Failed to write admin file!!");
        }
    }

    public static void writeToPaymentFile(){
        try{
            //Write to paymentInfo File
            PrintWriter x = new PrintWriter("paymentInfo.txt");
            for (Payment a: allPayments){
                x.println(a.getPaymentID());
                x.println(a.getPaymentDate());
                x.println(a.getPaymentBooking().getBookingID());
                x.println(a.getPaymentCustomer().getAccID());
                x.println(a.getTotalPayment());
                x.println(a.getRating());
                x.println();       
            }
            x.close();
        }catch(Exception e){
            System.out.println("Failed to write payment file!!");
        }
    }     
   
    public static Customer checkAccID(String id){ //username validation
        Customer found = null; 
        for(Customer c : allCustomers){
            if(id.equals(c.getAccID())){
                found = c;
                break;
            }
        }
        return found;
    }
    
    public static Car checkCarID(String id){
        Car found = null;
        for(Car x : allCars){
            if(id.equals(x.getCarID())){
                found = x;
                break;
            }
        }
        return found;
    }
    
    public static Admin checkAdminAccID(String id){ //username validation
        Admin found = null; 
        for(Admin a : allAdmins){
            if(id.equals(a.getAccID())){
                found = a;
                break;
            }
        }
        return found;
    }

    public static Booking checkBookingID(String id){
        Booking found = null;
        for(Booking x : allBookings){
            if(id.equals(x.getBookingID())){
                found = x;
                break;
            }
        }
        return found;
    }
    
    
    // auto generate Customer ID
    public static String autogenerateCusID(){
        String newID = null;
        int size = allCustomers.size();
        if (size == 0){
            newID = "000001";
        } else {
            String accID = allCustomers.get(size-1).getAccID();
            int number = Integer.parseInt(accID.substring(3));
            int newnumber = number + 1;
            if (newnumber < 10){
                newID = "00000" + Integer.toString(newnumber);
            } else if (newnumber < 100){
                newID = "0000" + Integer.toString(newnumber);
            } else if (newnumber < 1000){
                newID = "000" + Integer.toString(newnumber);
            } else if (newnumber < 10000){
                newID = "00" + Integer.toString(newnumber);
            } else if (newnumber < 100000){
                newID = "0" + Integer.toString(newnumber);
            } else {
                newID = Integer.toString(newnumber);
            }
        }      
        return ("CUS" + newID);
    } 
    
    // auto generate Admin ID
    public static String autogenerateAdminID(){
        String newID = null;
        int size = allAdmins.size();
        String accID = allAdmins.get(size-1).getAccID();
        int number = Integer.parseInt(accID.substring(3));
        int newnumber = number + 1;
        if (newnumber < 10){
            newID = "000" + Integer.toString(newnumber);
        } else if (newnumber < 100){
            newID = "00" + Integer.toString(newnumber);
        } else if (newnumber < 1000){
            newID = "0" + Integer.toString(newnumber);
        } else {
            newID = Integer.toString(newnumber);
        }
        return ("ADM" + newID);
    }
    
    
    
    // auto generate Car ID
    public static String autogenerateCarID(){
        String newID = null;
        int size = allCars.size();      
        if (size == 0){
            newID = "0001";           
        } else{
            String carID = allCars.get(size-1).getCarID();
            int number = Integer.parseInt(carID.substring(1));
            int newnumber = number + 1;
            if (newnumber < 10){
            newID = "000" + Integer.toString(newnumber);
            } else if (newnumber < 100){
                newID = "00" + Integer.toString(newnumber);
            } else if (newnumber < 1000){
                newID = "0" + Integer.toString(newnumber);
            } else {
                newID = Integer.toString(newnumber);
            }
        }
        return ("C" + newID);     
    }
    
    // auto generate Booking ID
    public static String autogenerateBookingID(){
        String newID = null;
        int size = allBookings.size();
        if (size == 0){
            newID = "000001";
        } else {
            String bookingID = allBookings.get(size-1).getBookingID();
            int number = Integer.parseInt(bookingID.substring(2));
            int newnumber = number + 1;
            if (newnumber < 10){
                newID = "00000" + Integer.toString(newnumber);
            } else if (newnumber < 100){
                newID = "0000" + Integer.toString(newnumber);
            } else if (newnumber < 1000){
                newID = "000" + Integer.toString(newnumber);
            } else if (newnumber < 10000){
                newID = "00" + Integer.toString(newnumber);
            } else if (newnumber < 100000){
                newID = "0" + Integer.toString(newnumber);
            } else {
                newID = Integer.toString(newnumber);
            }
        }      
        return ("BK" + newID);
    }
    
    // auto generate 
    public static String autogeneratePaymentID(){
        String newID = null;
        int size = allPayments.size();
        if (size == 0){
            newID = "000001";
        } else {
            String paymentID = allPayments.get(size-1).getPaymentID();
            int number = Integer.parseInt(paymentID.substring(2));
            int newnumber = number + 1;
            if (newnumber < 10){
                newID = "00000" + Integer.toString(newnumber);
            } else if (newnumber < 100){
                newID = "0000" + Integer.toString(newnumber);
            } else if (newnumber < 1000){
                newID = "000" + Integer.toString(newnumber);
            } else if (newnumber < 10000){
                newID = "00" + Integer.toString(newnumber);
            } else if (newnumber < 100000){
                newID = "0" + Integer.toString(newnumber);
            } else {
                newID = Integer.toString(newnumber);
            }
        }      
        return ("PY" + newID);
    }
    
    public static boolean isNumeric(String str) { 
        try {  
          Double.parseDouble(str);  
          return true;
        } catch(NumberFormatException e){  
          return false;  
        }  
    }
   
}
