package carrentalsystem;

import java.util.ArrayList;

public class Customer extends User {
    private Sex gender; 
    private String email, address;
    private int phoneNum;
    private ArrayList<Booking> myBooking = new ArrayList<Booking>();
    private ArrayList<Payment> myPayment = new ArrayList<Payment>();

    public ArrayList<Payment> getMyPayment() {
        return myPayment;
    }

    public void setMyPayment(ArrayList<Payment> myPayment) {
        this.myPayment = myPayment;
    }
    
    public ArrayList<Booking> getMyBooking() {
        return myBooking;
    }

    public void setMyBooking(ArrayList<Booking> myBooking) {
        this.myBooking = myBooking;
    }

    public Sex getGender() {
        return gender;
    }
    public void setGender(Sex gender) {
        this.gender = gender;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }

    public int getPhoneNum() {
        return phoneNum;
    }
    public void setPhoneNum(int phoneNum) {
        this.phoneNum = phoneNum;
    }

    public Customer(String accID, String username, Sex gender, String email, String address, int phoneNum, String password) {
        super(accID, username, password);
        this.gender = gender;
        this.email = email;
        this.address = address;
        this.phoneNum = phoneNum;
    }

    
  
}
