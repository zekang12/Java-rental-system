package carrentalsystem;

/**
 *
 * @author zekang
 */
public class Car {
    private String CarID, Model, Status;
    private int ManufactureYear;
    private double RentPrice;

    public String getCarID() {
        return CarID;
    }

    public void setCarID(String CarID) {
        this.CarID = CarID;
    }

    public String getModel() {
        return Model;
    }

    public void setModel(String Model) {
        this.Model = Model;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }

    public int getManufactureYear() {
        return ManufactureYear;
    }

    public void setManufactureYear(int ManufactureYear) {
        this.ManufactureYear = ManufactureYear;
    }

    public double getRentPrice() {
        return RentPrice;
    }

    public void setRentPrice(double RentPrice) {
        this.RentPrice = RentPrice;
    }

    public Car(String CarID, String Model, String Status, int ManufactureYear, double RentPrice) {
        this.CarID = CarID;
        this.Model = Model;
        this.Status = Status;
        this.ManufactureYear = ManufactureYear;
        this.RentPrice = RentPrice;
    }
}
