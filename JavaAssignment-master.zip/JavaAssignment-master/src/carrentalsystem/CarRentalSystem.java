package carrentalsystem;
public class CarRentalSystem {
    public static LoginPage page1; 
    public static SplashScreen loading;
    public static Customer loginUser = null;
    public static Car loginCar = null;           
    public static Booking loginBooking = null;
    public static Payment loginPayment = null;
    public static Admin loginAdmin = null;
    public static void main(String[] args) {
        InformationIO.readFromCusFile();
        InformationIO.readFromAdminFile();
        InformationIO.readFromCarFile();
        InformationIO.readFromBookingFile();
        InformationIO.readFromPaymentFile();
        //loading = new SplashScreen();
        //loading.setVisible(true);
        page1 = new LoginPage();

    }
    
}
