package carrentalsystem;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class CustomerManagementPage implements ActionListener{
    public void goBack(){
        // Search, Delete, Edit, and,Exit Buttons are displayed       
        deleteButton.setVisible(true); 
        seachNowButton.setVisible(true); 
        editButton.setVisible(true);
        exitButton.setVisible(true);

        // Save and Back Buttons are hidden
        saveButton.setVisible(false);           
        backButton.setVisible(false);           
        
        // reset everything 
                                            
        accountIDField.setText(null);
        usernameField.setText(null);
        emailField.setText(null);
        addressField.setText(null);
        phoneNumField.setText(null);

        // Only AccountID can be entered
        accountIDField.setEditable(true);
        usernameField.setEditable(false);
        genderCombobox.setEnabled(false);
        emailField.setEditable(false);
        addressField.setEditable(false);
        phoneNumField.setEditable(false);
    }
    
    public void actionPerformed(ActionEvent e){
        try{
                       
            if (e.getSource() == editButton){
                // Only Save and back Buttons are displayed               
                saveButton.setVisible(true);
                backButton.setVisible(true);              
                editButton.setVisible(false);                        
                exitButton.setVisible(false);
                seachNowButton.setVisible(false);
                deleteButton.setVisible(false);
                
                // Every text field become editable
                accountIDField.setEditable(true);
                usernameField.setEditable(true);
                emailField.setEditable(true);
                addressField.setEditable(true);
                phoneNumField.setEditable(true);
                genderCombobox.setEnabled(true);

            } else if (e.getSource() == deleteButton){            
                String accID = accountIDField.getText();
                boolean found = false;
                int i = 0;
                for(i=0; i< InformationIO.allCustomers.size(); i++){
                    Customer c = InformationIO.allCustomers.get(i);
                    if(accID.equals(c.getAccID())){
                        found = true;
                        InformationIO.allCustomers.remove(c);
                        break;
                    }
                }
                if(found){
                    // Modify the table
                    DefaultTableModel model = (DefaultTableModel) table.getModel();
                    model.removeRow(i);
                    
                    // Back to previous page
                    goBack();
                    
                } else{
                    JOptionPane.showMessageDialog(frame, "The  Account ID must be valid");
                }


            } else if (e.getSource () == exitButton){
                InformationIO.writeToCusFile();
                frame.setVisible(false);
                AdminHomePage home_page = new AdminHomePage(); 
                home_page.setVisible(true);

            } else if (e.getSource() == saveButton){
                Customer current = null;
                String accID = accountIDField.getText();
                boolean found = false;
                int i = 0;
                for(i=0; i< InformationIO.allCustomers.size(); i++){
                    Customer c = InformationIO.allCustomers.get(i);
                    if(accID.equals(c.getAccID())){
                        found = true;
                        current = c;
                        break;
                    }
                }
                if (found){
                    String username = usernameField.getText();
                    String gender = genderCombobox.getSelectedItem().toString();
                    String email = emailField.getText();
                    String address = addressField.getText();
                    int phoneNum = Integer.parseInt(phoneNumField.getText());
                    
                    if (username.isEmpty() || email.isEmpty() || address.isEmpty()){
                        JOptionPane.showMessageDialog(frame, "The Field cannot left empty");                    
                    } else if (!username.matches("^[a-zA-Z]*$")){
                        JOptionPane.showMessageDialog(frame, "The username must be a string");
                    } else if (InformationIO.isNumeric(email) == true){
                        JOptionPane.showMessageDialog(frame, "Email cannot be numeric value");
                    } else if (InformationIO.isNumeric(address) == true){
                        JOptionPane.showMessageDialog(frame, "Address cannot be numeric value");                    
                    } else {
                        current.setUsername(username);
                        current.setGender(Sex.valueOf(gender));
                        current.setEmail(email);
                        current.setAddress(address);
                        current.setPhoneNum(phoneNum);
                        
                        // Modify the table
                        DefaultTableModel model = (DefaultTableModel) table.getModel();
                        model.setValueAt(username, i, 1);
                        model.setValueAt(gender, i, 2);                    
                        model.setValueAt(email, i, 3);                    
                        model.setValueAt(address, i, 4);                    
                        model.setValueAt(phoneNum, i, 5);                    
                        // Back to previous page
                        goBack();
                    }    
                                  
                } else {
                    JOptionPane.showMessageDialog(frame, "The Account ID must be valid");
                }
            
                
            } else if (e.getSource() == seachNowButton){                
                String accID = accountIDField.getText();
                Customer found = InformationIO.checkAccID(accID);
                if (found != null){
                    genderCombobox.setEnabled(true);                    
                    String username = found.getUsername();
                    Sex gender = found.getGender();
                    String email = found.getEmail();
                    String address = found.getAddress();
                    int phonenum = found.getPhoneNum();
                    usernameField.setText(username);
                    genderCombobox.setSelectedItem(gender);
                    emailField.setText(email);
                    addressField.setText(address);
                    phoneNumField.setText(Integer.toString(phonenum));
                    genderCombobox.setEnabled(false);
                    
                } else{
                    JOptionPane.showMessageDialog(frame, "The Account ID must be valid");
                }
                
            } else if (e.getSource() == backButton){   
                goBack();

            }
        } catch (Exception ex){
            JOptionPane.showMessageDialog(frame, "Invalid input!");
        }
    }
    
    public JFrame getJFrame(){
        return frame;
    }
    
    private JFrame frame;
    private JPanel upperPanel, input_Panel, button_Panel, lowerPanel, headerPanel;
    private JLabel accountIDLabel,usernameLabel, emailLabel, genderLabel, 
            addressLabel, phoneNumLabel, headerLabel;
    private JButton editButton, deleteButton, exitButton, saveButton, seachNowButton, backButton;
    private JTextField accountIDField, usernameField, emailField, addressField, phoneNumField; 
    private DefaultTableModel tableModel;
    private JTable table;
    private Font titleFont, subtitleFont;
    private JComboBox genderCombobox;


    public CustomerManagementPage(){
        frame = new JFrame("Customer Management Page");
        frame.setSize(1250,500);
        frame.setLocation(500,300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        
        frame.setLayout(new GridLayout(1,2));
        
        titleFont = new Font(null, Font.BOLD, 24);
        subtitleFont = new Font(null, Font.PLAIN, 14);
        
        // Panel
        upperPanel = new JPanel();
        upperPanel.setLayout(new BorderLayout());
        input_Panel = new JPanel();
        input_Panel.setLayout(null);
        button_Panel = new JPanel();
        lowerPanel = new JPanel(new GridLayout());
        headerPanel = new JPanel();
        
        // hearder
        headerPanel.setBackground(Color.GRAY);
        headerLabel = new JLabel("*Customer Account Management*");
        headerLabel.setFont(titleFont);
        headerLabel.setForeground(Color.white);
        headerPanel.add(headerLabel);
        upperPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Label
        accountIDLabel = new JLabel("AccountID");
        usernameLabel = new JLabel("Username");
        genderLabel = new JLabel("Gender");
        emailLabel = new JLabel("Email");
        addressLabel = new JLabel("Address");
        phoneNumLabel = new JLabel("Phone Number");
        
        accountIDLabel.setBounds(100,50,100,25);
        usernameLabel.setBounds(100,100,100,25);
        genderLabel.setBounds(100,150,100,25);
        emailLabel.setBounds(100,200,100,25);
        addressLabel.setBounds(100,250,100,25);
        phoneNumLabel.setBounds(75,300,150,25);
                
        accountIDLabel.setFont(subtitleFont);
        usernameLabel.setFont(subtitleFont);
        genderLabel.setFont(subtitleFont);
        emailLabel.setFont(subtitleFont);
        addressLabel.setFont(subtitleFont);
        phoneNumLabel.setFont(subtitleFont);
        
        input_Panel.add(accountIDLabel);
        input_Panel.add(usernameLabel);
        input_Panel.add(genderLabel);
        input_Panel.add(emailLabel);
        input_Panel.add(addressLabel);
        input_Panel.add(phoneNumLabel);
        
        // Text Field
        accountIDField = new JTextField(10);
        usernameField = new JTextField(10);
        emailField = new JTextField(10);
        addressField = new JTextField(10);
        phoneNumField = new JTextField(10);
                
        accountIDField.setBounds(200,50,100,25);
        usernameField.setBounds(200,100,150,25);
        emailField.setBounds(200,200,150,25);
        addressField.setBounds(200,250,150,25);
        phoneNumField.setBounds(200,300,150,25);
               
        input_Panel.add(accountIDField);
        input_Panel.add(usernameField);
        input_Panel.add(emailField);
        input_Panel.add(addressField);
        input_Panel.add(phoneNumField);
        
        // ComboBox
        String [] gender = {"Male", "Female"};
        genderCombobox = new JComboBox(gender);
        genderCombobox.setBounds(200,150,100,25);
        input_Panel.add(genderCombobox);
       
        // Button
        editButton = new JButton("Edit");
        deleteButton = new JButton("Delete");
        exitButton = new JButton("Exit");
        saveButton = new JButton("Save");   
        seachNowButton = new JButton("Search");
        backButton = new JButton("Back");
  
        editButton.addActionListener(this);
        deleteButton.addActionListener(this);
        exitButton.addActionListener(this);
        saveButton.addActionListener(this);
        seachNowButton.addActionListener(this);
        backButton.addActionListener(this);
        
        button_Panel.add(editButton);
        button_Panel.add(deleteButton);        
        button_Panel.add(saveButton);
        button_Panel.add(seachNowButton);
        button_Panel.add(exitButton);
        button_Panel.add(backButton);
               
        // Add input and button to upper panel
        upperPanel.add(button_Panel, BorderLayout.SOUTH);      
        upperPanel.add(input_Panel, BorderLayout.CENTER);
        frame.add(upperPanel);
        
        // Save and Back Buttons are hidden
        saveButton.setVisible(false);
        backButton.setVisible(false);
        
        // Only AccountID can be entered
        accountIDField.setEditable(true);
        usernameField.setEditable(false);
        genderCombobox.setEnabled(false);
        emailField.setEditable(false);
        addressField.setEditable(false);
        phoneNumField.setEditable(false);
        
    
        // Table
        int size = InformationIO.allCustomers.size();       
        String[][] data = new String[size][6];
        for(int i=0; i<size; i++){
            Customer c = InformationIO.allCustomers.get(i);
            data[i][0] = c.getAccID();
            data[i][1] = c.getUsername();
            data[i][2] = ""+c.getGender();
            data[i][3] = c.getEmail();
            data[i][4] = c.getAddress();
            data[i][5] = ""+c.getPhoneNum();

        }
        String[] columnNames = {"AccountID", "Username", "Gender", "Email", "Address", "Phone Number" };
        tableModel = new DefaultTableModel(data, columnNames);
        table = new JTable(tableModel);
        table.setEnabled(false);
        table.getColumnModel().getColumn(2).setPreferredWidth(50);
        table.getColumnModel().getColumn(3).setPreferredWidth(150);
        JScrollPane sp = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, 
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        lowerPanel.add(sp);
        frame.add(lowerPanel);
        
        frame.setVisible(true);
            
    } 
}
