package carrentalsystem;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class superAdminHomePage implements ActionListener {
    
    public void goBack(){
        // Add, Edit, ,Exit, Search Buttons are displayed
        addButton.setVisible(true);
        editButton.setVisible(true);
        exitButton.setVisible(true);
        searchButton.setVisible(true);

        // Save, Delete and Back Buttons are hidden
        saveButton.setVisible(false);           
        deleteButton.setVisible(false); 
        seachNowButton.setVisible(false); 
        backButton.setVisible(false); 

        // reset everything 
        String fullId = InformationIO.autogenerateAdminID();
        accountIDField.setText(fullId);                                     
        usernameField.setText(null);
        passwordField.setText(null);
        accountIDField.setEditable(false);
        usernameField.setEditable(true);
        passwordField.setEditable(true);
    }
    
    public void actionPerformed(ActionEvent e){
        try{
            if (e.getSource() == addButton){
                String accountID = accountIDField.getText();
                String username = usernameField.getText();
                String password = passwordField.getText();
                if (username.isEmpty() || password.isEmpty()){
                    JOptionPane.showMessageDialog(frame, "The Field cannot left empty");                    
                } else if (!username.matches("^[a-zA-Z]*$")){
                    JOptionPane.showMessageDialog(frame, "The username must be a string");
                } else {                    
                    Admin a = new Admin(accountID, username, password);
                    InformationIO.allAdmins.add(a);
                    // Modify the table
                    DefaultTableModel model = (DefaultTableModel) table.getModel();
                    model.addRow(new Object[]{accountID,username,password});
                    // Autogenerate AdminID
                    String fullId = InformationIO.autogenerateAdminID();
                    accountIDField.setText(fullId);
                    usernameField.setText(null);
                    passwordField.setText(null);
                }
                       
            } else if (e.getSource() == editButton){
                // Save and Delete Buttons are displayed
                saveButton.setVisible(true);
                deleteButton.setVisible(true);
                backButton.setVisible(true);
                // Add, Edit, and Exit Buttons are hidden
                addButton.setVisible(false);
                editButton.setVisible(false);                        
                exitButton.setVisible(false);
                searchButton.setVisible(false);
                // reset everything and accountID Text Field become editable
                accountIDField.setText(null);
                usernameField.setText(null);
                passwordField.setText(null);
                accountIDField.setEditable(true);

            } else if (e.getSource() == deleteButton){            
                String accountID = accountIDField.getText();
                boolean found = false;
                int i = 0;
                for(i=0; i< InformationIO.allAdmins.size(); i++){
                    Admin a = InformationIO.allAdmins.get(i);
                    if(accountID.equals(a.getAccID())){
                        found = true;
                        InformationIO.allAdmins.remove(a);
                        break;
                    }
                }
                if(found){
                    // Modify the table
                    DefaultTableModel model = (DefaultTableModel) table.getModel();
                    model.removeRow(i);
                    
                    // Back to previous page
                    goBack();
                    
                } else{
                    JOptionPane.showMessageDialog(frame, "The accountID must be valid");
                }


            } else if (e.getSource () == exitButton){
                InformationIO.writeToAdminFile();
                frame.setVisible(false);
                LoginPage page1 = new LoginPage(); 
                page1.getJFrame().setVisible(true);


            } else if (e.getSource() == saveButton){
                Admin current = null;
                String accountID = accountIDField.getText();
                boolean found = false;
                int i = 0;
                for(i=0; i< InformationIO.allAdmins.size(); i++){
                    Admin a = InformationIO.allAdmins.get(i);
                    if(accountID.equals(a.getAccID())){
                        found = true;
                        current = a;
                        break;
                    }
                }
                if (found){
                    String username = usernameField.getText();
                    String password = passwordField.getText();
                    
                    if (username.isEmpty() || password.isEmpty()){
                        JOptionPane.showMessageDialog(frame, "The Field cannot left empty");                    
                    } else if (!username.matches("^[a-zA-Z]*$")){
                        JOptionPane.showMessageDialog(frame, "The username must be a string");                        
                    } else {
                        current.setUsername(username);
                        current.setPassword(password);
                        
                        // Modify the table
                        DefaultTableModel model = (DefaultTableModel) table.getModel();
                        model.setValueAt(username, i, 1);
                        model.setValueAt(password, i, 2);                    
                        // Back to previous page
                        goBack();
                    }                 
                } else {
                    JOptionPane.showMessageDialog(frame, "The accountID must be valid");
                }
                
            } else if (e.getSource() == searchButton){

                // Add, Edit, and Exit Buttons are hidden
                addButton.setVisible(false);
                editButton.setVisible(false);                        
                exitButton.setVisible(false);
                searchButton.setVisible(false);
                
                // Back Button are displayed
                seachNowButton.setVisible(true);
                backButton.setVisible(true);
                
                // reset everything and accountID Text Field become editable
                accountIDField.setText(null);
                usernameField.setText(null);
                passwordField.setText(null);
                accountIDField.setEditable(true);
                usernameField.setEditable(false);
                passwordField.setEditable(false);
            
                
            } else if (e.getSource() == seachNowButton){
                String accountID = accountIDField.getText();
                Admin found = InformationIO.checkAdminAccID(accountID);
                if (found != null){
                    String username = found.getUsername();
                    String password = found.getPassword();
                    usernameField.setText(username);
                    passwordField.setText(password);
                    
                } else{
                    JOptionPane.showMessageDialog(frame, "The accountID must be valid");
                }
                
           
            } else if (e.getSource() == backButton){
                // Back to previous page
                goBack();
            } 
        } catch (Exception ex){
            JOptionPane.showMessageDialog(frame, "Invalid input!");
        }
    }
    
    public JFrame getJFrame(){
        return frame;
    }
    
    private JFrame frame;
    private JPanel upperPanel, input_Panel, accountID_Panel, username_Panel, 
            password_Panel, button_Panel, lowerPanel, headerPanel;
    private JLabel accountIDLabel,usernameLabel, passwordLabel, headerLabel;
    private JButton addButton, editButton, deleteButton, exitButton, saveButton, 
            searchButton, backButton, seachNowButton;
    private JTextField accountIDField, usernameField, passwordField;
    private DefaultTableModel tableModel;
    private JTable table;
    private Font titleFont, subtitleFont;


    public superAdminHomePage(){
        frame = new JFrame("Super Admin Page");
        frame.setSize(500,350);
        frame.setLocation(700,300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        
        frame.setLayout(new GridLayout(2,1));
        
        titleFont = new Font(null, Font.BOLD, 24);
        subtitleFont = new Font(null, Font.PLAIN, 14);
        
        // Panel
        upperPanel = new JPanel();
        upperPanel.setLayout(new BorderLayout());
        input_Panel = new JPanel();
        input_Panel.setLayout(new GridLayout(2,3));
        accountID_Panel = new JPanel();
        username_Panel = new JPanel();
        password_Panel = new JPanel();
        button_Panel = new JPanel();
        lowerPanel = new JPanel(new GridLayout());
        headerPanel = new JPanel();
        
        // hearder
        headerPanel.setBackground(Color.GRAY);
        headerLabel = new JLabel("*Super Admin Home Page*");
        headerLabel.setFont(titleFont);
        headerLabel.setForeground(Color.white);
        headerPanel.add(headerLabel);
        upperPanel.add(headerPanel, BorderLayout.NORTH);
        //frame.add(, BorderLayout.NORTH);
        

        // Label
        accountIDLabel = new JLabel("AccountID", JLabel.CENTER);
        usernameLabel = new JLabel("Username", JLabel.CENTER);
        passwordLabel = new JLabel("Password", JLabel.CENTER);
        
        accountIDLabel.setFont(subtitleFont);
        usernameLabel.setFont(subtitleFont);
        passwordLabel.setFont(subtitleFont);
        
        input_Panel.add(accountIDLabel);
        input_Panel.add(usernameLabel);
        input_Panel.add(passwordLabel);
        
        // Text Field
        accountIDField = new JTextField(10);
        usernameField = new JTextField(10);
        passwordField = new JTextField(10);
        
        // auto generate ID
        String fullId = InformationIO.autogenerateAdminID();
        accountIDField.setText(fullId);
        // accountID Text Field become not editable         
        accountIDField.setEditable(false); 
        
        accountID_Panel.add(accountIDField);
        username_Panel.add(usernameField);
        password_Panel.add(passwordField);
        
        input_Panel.add(accountID_Panel);
        input_Panel.add(username_Panel);
        input_Panel.add(password_Panel);
        
        // Button
        addButton = new JButton("Add");
        editButton = new JButton("Edit");
        deleteButton = new JButton("Delete");
        exitButton = new JButton("Logout");
        saveButton = new JButton("Save");
        searchButton = new JButton("Search");
        seachNowButton = new JButton("Search Now");
        backButton = new JButton("Go Back");
        
        saveButton.setVisible(false);
        deleteButton.setVisible(false);
        seachNowButton.setVisible(false);
        backButton.setVisible(false);
        
        addButton.addActionListener(this);
        editButton.addActionListener(this);
        deleteButton.addActionListener(this);
        exitButton.addActionListener(this);
        saveButton.addActionListener(this);
        searchButton.addActionListener(this);
        seachNowButton.addActionListener(this);
        backButton.addActionListener(this);
        
        button_Panel.add(addButton);
        button_Panel.add(editButton);
        button_Panel.add(deleteButton);        
        button_Panel.add(saveButton);
        button_Panel.add(searchButton);
        button_Panel.add(seachNowButton);
        button_Panel.add(backButton);
        button_Panel.add(exitButton);
               
        // Add input and button to upper panel
        upperPanel.add(button_Panel, BorderLayout.SOUTH);      
        upperPanel.add(input_Panel, BorderLayout.CENTER);
        frame.add(upperPanel);
        
        
        // Table
        int size = InformationIO.allAdmins.size();
        
        String[][] data = new String[size][3];
        for(int i=0; i<size; i++){
            Admin a = InformationIO.allAdmins.get(i);
            data[i][0] = a.getAccID();
            data[i][1] = a.getUsername();
            data[i][2] = ""+a.getPassword();
        }
        String[] columnNames = {"Account ID", "Username", "Password" };
        tableModel = new DefaultTableModel(data, columnNames);
        table = new JTable(tableModel);
        table.setEnabled(false);
        table.getColumnModel().getColumn(0).setPreferredWidth(-50);
        JScrollPane sp = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, 
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        lowerPanel.add(sp);
        frame.add(lowerPanel);
        
        frame.setVisible(true);
            
    }  
    
}
