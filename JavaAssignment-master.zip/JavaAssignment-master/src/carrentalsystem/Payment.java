package carrentalsystem;

import java.util.ArrayList;

/**
 *
 * @author zekang
 */
public class Payment {
    private String paymentID, paymentDate;
    private Booking paymentBooking;
    private Customer paymentCustomer;
    private double totalPayment;
    private int rating;

    public String getPaymentID() {
        return paymentID;
    }

    public void setPaymentID(String paymentID) {
        this.paymentID = paymentID;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    public Booking getPaymentBooking() {
        return paymentBooking;
    }

    public void setPaymentBooking(Booking paymentBooking) {
        this.paymentBooking = paymentBooking;
    }

    public Customer getPaymentCustomer() {
        return paymentCustomer;
    }

    public void setPaymentCustomer(Customer paymentCustomer) {
        this.paymentCustomer = paymentCustomer;
    }

    public double getTotalPayment() {
        return totalPayment;
    }

    public void setTotalPayment(double totalPayment) {
        this.totalPayment = totalPayment;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public Payment(String paymentID, String paymentDate, Booking paymentBooking, Customer paymentCustomer, double totalPayment, int rating) {
        this.paymentID = paymentID;
        this.paymentDate = paymentDate;
        this.paymentBooking = paymentBooking;
        this.paymentCustomer = paymentCustomer;
        this.totalPayment = totalPayment;
        this.rating = rating;
    }



}
