package carrentalsystem;
public enum Sex {
    Male, Female;
}
