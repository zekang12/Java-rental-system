package carrentalsystem;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class BookingManagementPage implements ActionListener {
    
    public void resetAllTextField(){
        bookingIDField.setText(null);
        rentDateField.setText(null);
        returnDateField.setText(null);
        totalRentalField.setText(null);
        cusIDField.setText(null);
        carIDField.setText(null);
    }
    
    public void goBack(){
        // Search, Delete, Edit, and,Exit Buttons are displayed       
        deleteButton.setVisible(true); 
        seachNowButton.setVisible(true); 
        editButton.setVisible(true);
        exitButton.setVisible(true);

        // Save and Back Buttons are hidden
        saveButton.setVisible(false);           
        backButton.setVisible(false);           
        
        // reset everything 
        resetAllTextField();                                    
        
        // Only AccountID can be entered
        bookingIDField.setEditable(true);
        rentDateField.setEditable(false);
        statusCombobox.setEnabled(false);
        returnDateField.setEditable(false);
        totalRentalField.setEditable(false);
        cusIDField.setEditable(false);
        carIDField.setEditable(false);
    }
    
    public void actionPerformed(ActionEvent e){
        try{
                       
            if (e.getSource() == editButton){
                // Only Save and back Buttons are displayed               
                saveButton.setVisible(true);
                backButton.setVisible(true);              
                editButton.setVisible(false);                        
                exitButton.setVisible(false);
                seachNowButton.setVisible(false);
                deleteButton.setVisible(false);
                
                // Every text field become editable except Booking ID
                bookingIDField.setEditable(false);
                rentDateField.setEditable(true);
                returnDateField.setEditable(true);
                totalRentalField.setEditable(true);
                cusIDField.setEditable(true);
                carIDField.setEditable(true);
                statusCombobox.setEnabled(true);

            } else if (e.getSource() == deleteButton){            
                String bookingID = bookingIDField.getText();
                boolean found = false;
                int i = 0;
                for(i=0; i< InformationIO.allBookings.size(); i++){
                    Booking b = InformationIO.allBookings.get(i);
                    if(bookingID.equals(b.getBookingID())){
                        found = true;
                        InformationIO.allBookings.remove(b);
                        break;
                    }
                }
                if(found){
                    // Modify the table
                    DefaultTableModel model = (DefaultTableModel) table.getModel();
                    model.removeRow(i);
                    
                    // Back to previous page
                    goBack();
                    
                } else{
                    resetAllTextField();                                    
                    JOptionPane.showMessageDialog(frame, "The  Booking ID must be valid");
                }


            } else if (e.getSource () == exitButton){
                InformationIO.writeToBookingFile();
                frame.setVisible(false);
                AdminHomePage home_page = new AdminHomePage(); 
                home_page.setVisible(true);

            } else if (e.getSource() == saveButton){
                Booking current = null;
                String bookingID = bookingIDField.getText();
                boolean found = false;
                int i = 0;
                for(i=0; i< InformationIO.allBookings.size(); i++){
                    Booking b = InformationIO.allBookings.get(i);
                    if(bookingID.equals(b.getBookingID())){
                        found = true;
                        current = b;
                        break;
                    }
                }
                if (found){
                    String rentDate = rentDateField.getText();
                    String returnDate = returnDateField.getText();
                    String status = statusCombobox.getSelectedItem().toString();                   
                    double totalRental = Double.parseDouble(totalRentalField.getText());
                    String cusID = cusIDField.getText();
                    String carID = carIDField.getText();
                    
                    Customer foundcus = InformationIO.checkAccID(cusID);
                    Car foundcar = InformationIO.checkCarID(carID);
                                       
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/uuuu");           
                    LocalDate date1 = LocalDate.parse(rentDate,formatter);
                    LocalDate date2 = LocalDate.parse(returnDate,formatter);
                    long daysBetween = ChronoUnit.DAYS.between(date1, date2);
                    //int num = Math.toIntExact(daysBetween);
                                       
                    if (rentDate.isEmpty() || returnDate.isEmpty()){
                        JOptionPane.showMessageDialog(frame, "The Field cannot left empty");                    
                    } else if (daysBetween < 0){
                        JOptionPane.showMessageDialog(frame, "Return Date must be late than Rent Date"); 
                    } else if (totalRental < 0){
                        JOptionPane.showMessageDialog(frame, "Rental Must be greater than 0");
                    } else if (foundcus == null){
                        JOptionPane.showMessageDialog(frame, "Customer ID must be valid"); 
                    } else if (foundcar == null){
                        JOptionPane.showMessageDialog(frame, "Car ID must be valid"); 
                    } else {
                        current.setRentDate(rentDate);
                        current.setReturnDate(returnDate);
                        current.setStatus(status);
                        current.setTotalRental(totalRental);
                        current.setOwner(foundcus);
                        current.setCar(foundcar);
                        
                        // Modify the table
                        DefaultTableModel model = (DefaultTableModel) table.getModel();
                        model.setValueAt(rentDate, i, 1);
                        model.setValueAt(returnDate, i, 2);                    
                        model.setValueAt(status, i, 3);                    
                        model.setValueAt(totalRental, i, 4);                    
                        model.setValueAt(cusID, i, 5);                    
                        model.setValueAt(carID, i, 6);                    
                        // Back to previous page
                        goBack();
                    }    
                                  
                } else {
                    JOptionPane.showMessageDialog(frame, "The Booking ID must be valid");
                }
            
                
            } else if (e.getSource() == seachNowButton){                
                String bookingID = bookingIDField.getText();
                Booking found = InformationIO.checkBookingID(bookingID);
                if (found != null){
                    statusCombobox.setEnabled(true);                    
                    String rentDate = found.getRentDate();
                    String returnDate = found.getReturnDate();
                    String status = found.getStatus();
                    double totalRent = found.getTotalRental();
                    String cusID = found.getOwner().getAccID();
                    String carID = found.getCar().getCarID();
                    rentDateField.setText(rentDate);
                    returnDateField.setText(returnDate);
                    statusCombobox.setSelectedItem(status);                   
                    totalRentalField.setText(Double.toString(totalRent));
                    cusIDField.setText(cusID);
                    carIDField.setText(carID);
                    statusCombobox.setEnabled(false);
                    
                } else{
                    resetAllTextField();                                    
                    JOptionPane.showMessageDialog(frame, "The Booking ID must be valid");
                }
                
            } else if (e.getSource() == backButton){   
                goBack();

            }
        } catch (Exception ex){
            JOptionPane.showMessageDialog(frame, "Invalid input!");
        }
    }
    
    public JFrame getJFrame(){
        return frame;
    }
    
    private JFrame frame;
    private JPanel upperPanel, input_Panel, button_Panel, lowerPanel, headerPanel;
    private JLabel bookingIDLabel,rentDateLabel, returnDateLabel, statusLabel, 
            totalRentalLabel, cusIDLabel, carIDLabel, headerLabel;
    private JButton editButton, deleteButton, exitButton, saveButton, seachNowButton, backButton;
    private JTextField bookingIDField, rentDateField, returnDateField, 
            totalRentalField, cusIDField, carIDField; 
    private DefaultTableModel tableModel;
    private JTable table;
    private Font titleFont, subtitleFont;
    private JComboBox statusCombobox;


    public BookingManagementPage(){
        frame = new JFrame("Booking Management Page");
        frame.setSize(1200,550);
        frame.setLocation(500,300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        
        frame.setLayout(new GridLayout(1,2));
        
        titleFont = new Font(null, Font.BOLD, 24);
        subtitleFont = new Font(null, Font.PLAIN, 14);
        
        // Panel
        upperPanel = new JPanel();
        upperPanel.setLayout(new BorderLayout());
        input_Panel = new JPanel();
        input_Panel.setLayout(null);
        button_Panel = new JPanel();
        lowerPanel = new JPanel(new GridLayout());
        headerPanel = new JPanel();
        
        // hearder
        headerPanel.setBackground(Color.GRAY);
        headerLabel = new JLabel("*Booking Management*");
        headerLabel.setFont(titleFont);
        headerLabel.setForeground(Color.white);
        headerPanel.add(headerLabel);
        upperPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Label
        bookingIDLabel = new JLabel("Booking ID");
        rentDateLabel = new JLabel("Rent Date");
        returnDateLabel = new JLabel("Return Date");
        statusLabel = new JLabel("Status");
        totalRentalLabel = new JLabel("Total Rental");
        cusIDLabel = new JLabel("Customer ID");
        carIDLabel = new JLabel("Car ID");
        
        bookingIDLabel.setBounds(100,50,100,25);
        rentDateLabel.setBounds(100,100,100,25);
        returnDateLabel.setBounds(100,150,100,25);
        statusLabel.setBounds(100,200,100,25);
        totalRentalLabel.setBounds(100,250,100,25);
        cusIDLabel.setBounds(100,300,100,25);
        carIDLabel.setBounds(100,350,100,25);
                
        bookingIDLabel.setFont(subtitleFont);
        rentDateLabel.setFont(subtitleFont);
        statusLabel.setFont(subtitleFont);
        returnDateLabel.setFont(subtitleFont);
        totalRentalLabel.setFont(subtitleFont);
        cusIDLabel.setFont(subtitleFont);
        carIDLabel.setFont(subtitleFont);
        
        input_Panel.add(bookingIDLabel);
        input_Panel.add(rentDateLabel);
        input_Panel.add(statusLabel);
        input_Panel.add(returnDateLabel);
        input_Panel.add(totalRentalLabel);
        input_Panel.add(cusIDLabel);
        input_Panel.add(carIDLabel);
        
        // Text Field
        bookingIDField = new JTextField(10);
        rentDateField = new JTextField(10);
        returnDateField = new JTextField(10);
        totalRentalField = new JTextField(10);
        cusIDField = new JTextField(10);
        carIDField = new JTextField(10);
                
        bookingIDField.setBounds(200,50,100,25);
        rentDateField.setBounds(200,100,100,25);
        returnDateField.setBounds(200,150,100,25);
        totalRentalField.setBounds(200,250,100,25);
        cusIDField.setBounds(200,300,100,25);
        carIDField.setBounds(200,350,100,25);
               
        input_Panel.add(bookingIDField);
        input_Panel.add(rentDateField);
        input_Panel.add(returnDateField);
        input_Panel.add(totalRentalField);
        input_Panel.add(cusIDField);
        input_Panel.add(carIDField);
        
        // ComboBox
        String [] status = {"Completed", "Pending"};
        statusCombobox = new JComboBox(status);
        statusCombobox.setBounds(200,200,100,25);
        input_Panel.add(statusCombobox);
       
        // Button
        editButton = new JButton("Edit");
        deleteButton = new JButton("Delete");
        exitButton = new JButton("Exit");
        saveButton = new JButton("Save");   
        seachNowButton = new JButton("Search");
        backButton = new JButton("Back");
  
        editButton.addActionListener(this);
        deleteButton.addActionListener(this);
        exitButton.addActionListener(this);
        saveButton.addActionListener(this);
        seachNowButton.addActionListener(this);
        backButton.addActionListener(this);
        
        button_Panel.add(editButton);
        button_Panel.add(deleteButton);        
        button_Panel.add(saveButton);
        button_Panel.add(seachNowButton);
        button_Panel.add(exitButton);
        button_Panel.add(backButton);
               
        // Add input and button to upper panel
        upperPanel.add(button_Panel, BorderLayout.SOUTH);      
        upperPanel.add(input_Panel, BorderLayout.CENTER);
        frame.add(upperPanel);
        
        // Save and Back Buttons are hidden
        saveButton.setVisible(false);
        backButton.setVisible(false);
        
        // Only AccountID can be entered
        bookingIDField.setEditable(true);
        rentDateField.setEditable(false);
        statusCombobox.setEnabled(false);
        returnDateField.setEditable(false);
        totalRentalField.setEditable(false);
        cusIDField.setEditable(false);
        carIDField.setEditable(false);
        
    
        // Table
        int size = InformationIO.allBookings.size();       
        String[][] data = new String[size][7];
        for(int i=0; i<size; i++){
            Booking b = InformationIO.allBookings.get(i);
            data[i][0] = b.getBookingID();
            data[i][1] = b.getRentDate();
            data[i][2] = b.getReturnDate();
            data[i][3] = b.getStatus();
            data[i][4] = ""+b.getTotalRental();
            data[i][5] = ""+b.getOwner().getAccID();
            data[i][6] = ""+b.getCar().getCarID();
        }
        String[] columnNames = {"BookingID", "Rent Date", "Return Date", "Status", "Total Rental", "Customer", "Car"};
        tableModel = new DefaultTableModel(data, columnNames);
        table = new JTable(tableModel);
        table.setEnabled(false);
        table.getColumnModel().getColumn(6).setPreferredWidth(50);
        //table.getColumnModel().getColumn(2).setPreferredWidth(-50);
        JScrollPane sp = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, 
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        lowerPanel.add(sp);
        frame.add(lowerPanel);
        
        frame.setVisible(true);
            
    } 
}
