
package carrentalsystem;

/**
 *
 * @author zekang
 */
public class Booking {
    private String BookingID, rentDate, returnDate, status;
    private double totalRental;
    private Customer owner;
    private Car car;

    public String getBookingID() {
        return BookingID;
    }

    public void setBookingID(String BookingID) {
        this.BookingID = BookingID;
    }

    public String getRentDate() {
        return rentDate;
    }

    public void setRentDate(String rentDate) {
        this.rentDate = rentDate;
    }

    public String getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(String returnDate) {
        this.returnDate = returnDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public double getTotalRental() {
        return totalRental;
    }

    public void setTotalRental(double totalRental) {
        this.totalRental = totalRental;
    }

    public Customer getOwner() {
        return owner;
    }

    public void setOwner(Customer owner) {
        this.owner = owner;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public Booking(String BookingID, String rentDate, String returnDate, String status, double totalRental, Customer owner, Car car) {
        this.BookingID = BookingID;
        this.rentDate = rentDate;
        this.returnDate = returnDate;
        this.status = status;
        this.totalRental = totalRental;
        this.owner = owner;
        this.car = car;
    }


    
}
