package carrentalsystem;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class CarManagementPage implements ActionListener {
    public void goBack(){
        // Add, Search and,Exit,  Buttons are displayed
        addButton.setVisible(true);        
        exitButton.setVisible(true);
        multipleButton.setVisible(true);

        // Save, Delete, Search, Edit and Back Buttons are hidden
        saveButton.setVisible(false);           
        deleteButton.setVisible(false); 
        seachNowButton.setVisible(false); 
        backButton.setVisible(false); 
        editButton.setVisible(false);

        // reset everything 
        String fullId = InformationIO.autogenerateCarID();
        carIDField.setText(fullId);                                     
        statusCombobox.setSelectedItem("Available");
                                             
        modelField.setText(null);
        dateField.setText(null);
        priceField.setText(null);

        carIDField.setEditable(false);
        statusCombobox.setEnabled(false);
        modelField.setEditable(true);
        dateField.setEditable(true);
        priceField.setEditable(true);
    }
    
    public void actionPerformed(ActionEvent e){
        try{
            if (e.getSource() == addButton){
                String carID = carIDField.getText();
                String carmodel = modelField.getText();
                String status = statusCombobox.getSelectedItem().toString();
                int year = Integer.parseInt(dateField.getText());
                double price = Double.parseDouble(priceField.getText());
                if (carmodel.isEmpty()){
                    JOptionPane.showMessageDialog(frame, "The Field cannot left empty");                    
                } else if (!carmodel.matches("^[a-zA-Z]*$")){
                    JOptionPane.showMessageDialog(frame, "The model must be a string");
                } else if (year <= 0 || year > 2022){
                    JOptionPane.showMessageDialog(frame, "The date must be valid");
                } else if (price <= 0){
                    JOptionPane.showMessageDialog(frame, "The price must be valid");    
                } else {                    
                    Car c = new Car(carID, carmodel, status, year, price);
                    InformationIO.allCars.add(c);
                    // Modify the table
                    DefaultTableModel model = (DefaultTableModel) table.getModel();
                    model.addRow(new Object[]{carID,carmodel,status, year, price});
                    // Autogenerate AdminID
                    String fullId = InformationIO.autogenerateCarID();
                    carIDField.setText(fullId);
                    modelField.setText(null);
                    dateField.setText(null);
                    priceField.setText(null);
                }
                       
            } else if (e.getSource() == editButton){
                // Save Button are displayed
                saveButton.setVisible(true);
                

                // Add, Edit, Search, Delete and Exit Buttons are hidden
                addButton.setVisible(false);
                editButton.setVisible(false);                        
                exitButton.setVisible(false);
                seachNowButton.setVisible(false);
                deleteButton.setVisible(false);
                // reset everything and accountID Text Field become editable
                carIDField.setEditable(true);
                modelField.setEditable(true);
                dateField.setEditable(true);
                priceField.setEditable(true);
                statusCombobox.setEnabled(true);

            } else if (e.getSource() == deleteButton){                   
                String carID = carIDField.getText();
                boolean found = false;
                int i = 0;
                for(i=0; i< InformationIO.allCars.size(); i++){
                    Car c = InformationIO.allCars.get(i);
                    if(carID.equals(c.getCarID())){
                        found = true;
                        InformationIO.allCars.remove(c);
                        break;
                    }
                }
                if(found){
                    // Modify the table
                    DefaultTableModel model = (DefaultTableModel) table.getModel();
                    model.removeRow(i);
                    
                    // Back to previous page
                    goBack();
                    
                } else{
                    JOptionPane.showMessageDialog(frame, "The  carID must be valid");
                }


            } else if (e.getSource () == exitButton){
                InformationIO.writeToCarFile();
                frame.setVisible(false);
                AdminHomePage home_page = new AdminHomePage(); 
                home_page.setVisible(true);


            } else if (e.getSource() == saveButton){
                Car current = null;
                String carID = carIDField.getText();
                boolean found = false;
                int i = 0;
                for(i=0; i< InformationIO.allCars.size(); i++){
                    Car c = InformationIO.allCars.get(i);
                    if(carID.equals(c.getCarID())){
                        found = true;
                        current = c;
                        break;
                    }
                }
                if (found){
                    String carmodel = modelField.getText();
                    String status = statusCombobox.getSelectedItem().toString();
                    int year = Integer.parseInt(dateField.getText());
                    double price = Double.parseDouble(priceField.getText());
                    
                    if (carmodel.isEmpty()){
                    JOptionPane.showMessageDialog(frame, "The Field cannot left empty");                    
                    } else if (!carmodel.matches("^[a-zA-Z]*$")){
                        JOptionPane.showMessageDialog(frame, "The model must be a string");
                    } else if (year <= 0 || year > 2022){
                        JOptionPane.showMessageDialog(frame, "The date must be valid");
                    } else if (price <= 0){
                        JOptionPane.showMessageDialog(frame, "The price must be valid");                     
                    } else {
                        current.setModel(carmodel);
                        current.setStatus(status);
                        current.setManufactureYear(year);
                        current.setRentPrice(price);
                        
                        // Modify the table
                        DefaultTableModel model = (DefaultTableModel) table.getModel();
                        model.setValueAt(carmodel, i, 1);
                        model.setValueAt(status, i, 2);                    
                        model.setValueAt(year, i, 3);                    
                        model.setValueAt(price, i, 4);                    
                        // Back to previous page
                        goBack();
                    }                 
                } else {
                    JOptionPane.showMessageDialog(frame, "The carID must be valid");
                }
                
            } else if (e.getSource() == multipleButton){

                // Add, Edit, and Exit Buttons are hidden
                addButton.setVisible(false);                       
                exitButton.setVisible(false);
                multipleButton.setVisible(false);
                
                // Back Button are displayed
                seachNowButton.setVisible(true);
                editButton.setVisible(true);
                deleteButton.setVisible(true);
                backButton.setVisible(true);
                
                // reset everything and accountID Text Field become editable
                carIDField.setText(null);
                modelField.setText(null);
                dateField.setText(null);
                priceField.setText(null);
                carIDField.setEditable(true);
                modelField.setEditable(false);
                statusCombobox.setEnabled(false);
                dateField.setEditable(false);
                priceField.setEditable(false);
            
                
            } else if (e.getSource() == seachNowButton){
                String carID = carIDField.getText();
                Car found = InformationIO.checkCarID(carID);
                if (found != null){
                    String carmodel = found.getModel();
                    String status = found.getStatus();
                    int year = found.getManufactureYear();
                    double price = found.getRentPrice();
                    modelField.setText(carmodel);
                    statusCombobox.setSelectedItem(status);
                    dateField.setText(Integer.toString(year));
                    priceField.setText(Double.toString(price));
                    
                } else{
                    JOptionPane.showMessageDialog(frame, "The Car ID must be valid");
                }
                
           
            } else if (e.getSource() == backButton){
                // Back to previous page
                goBack();
            } 
        } catch (Exception ex){
            JOptionPane.showMessageDialog(frame, "Invalid input!");
        }
    }
    
    public JFrame getJFrame(){
        return frame;
    }
    
    private JFrame frame;
    private JPanel upperPanel, input_Panel, button_Panel, lowerPanel, headerPanel;
    private JLabel carIDLabel,modelLabel, statusLabel, dateLabel, priceLabel, headerLabel;
    private JButton addButton, editButton, deleteButton, exitButton, saveButton, 
            multipleButton, backButton, seachNowButton;
    private JTextField carIDField, modelField, dateField, priceField; 
    private DefaultTableModel tableModel;
    private JTable table;
    private Font titleFont, subtitleFont;
    private JComboBox statusCombobox;


    public CarManagementPage(){
        frame = new JFrame("Car Information Management");
        frame.setSize(1000,450);
        frame.setLocation(700,300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        
        frame.setLayout(new GridLayout(1,2));
        
        titleFont = new Font(null, Font.BOLD, 24);
        subtitleFont = new Font(null, Font.PLAIN, 14);
        
        // Panel
        upperPanel = new JPanel();
        upperPanel.setLayout(new BorderLayout());
        input_Panel = new JPanel();
        input_Panel.setLayout(null);
        button_Panel = new JPanel();
        lowerPanel = new JPanel(new GridLayout());
        headerPanel = new JPanel();
        
        // hearder
        headerPanel.setBackground(Color.GRAY);
        headerLabel = new JLabel("*Car Information Management*");
        headerLabel.setFont(titleFont);
        headerLabel.setForeground(Color.white);
        headerPanel.add(headerLabel);
        upperPanel.add(headerPanel, BorderLayout.NORTH);
        

        // Label
        carIDLabel = new JLabel("CarID");
        modelLabel = new JLabel("Model");
        statusLabel = new JLabel("Status");
        dateLabel = new JLabel("Manufacture Year");
        priceLabel = new JLabel("Rent Price");
        
        carIDLabel.setBounds(100,50,100,25);
        modelLabel.setBounds(100,100,100,25);
        statusLabel.setBounds(100,150,100,25);
        dateLabel.setBounds(75,200,150,25);
        priceLabel.setBounds(100,250,100,25);
               
        carIDLabel.setFont(subtitleFont);
        modelLabel.setFont(subtitleFont);
        statusLabel.setFont(subtitleFont);
        dateLabel.setFont(subtitleFont);
        priceLabel.setFont(subtitleFont);
        
        input_Panel.add(carIDLabel);
        input_Panel.add(modelLabel);
        input_Panel.add(statusLabel);
        input_Panel.add(dateLabel);
        input_Panel.add(priceLabel);
        
        // Text Field
        carIDField = new JTextField(10);
        modelField = new JTextField(10);
        dateField = new JTextField(10);
        priceField = new JTextField(10);
        
        // auto generate ID
        String fullId = InformationIO.autogenerateCarID();
        carIDField.setText(fullId);
        // accountID Text Field become not editable         
        carIDField.setEditable(false); 
        
        carIDField.setBounds(200,50,100,25);
        modelField.setBounds(200,100,100,25);
        dateField.setBounds(200,200,100,25);
        priceField.setBounds(200,250,100,25);
               
        input_Panel.add(carIDField);
        input_Panel.add(modelField);
        input_Panel.add(dateField);
        input_Panel.add(priceField);

        
        // ComboBox
        String [] status = {"Available", "Booked", "Not Available"};
        statusCombobox = new JComboBox(status);
        statusCombobox.setBounds(200,150,100,25);
        statusCombobox.setSelectedItem("Available");
        statusCombobox.setEnabled(false);
        input_Panel.add(statusCombobox);
       
        // Button
        addButton = new JButton("Add");
        editButton = new JButton("Edit");
        deleteButton = new JButton("Delete");
        exitButton = new JButton("Exit");
        saveButton = new JButton("Save");
        multipleButton = new JButton("Search / Delete / Edit");
        seachNowButton = new JButton("Search");
        backButton = new JButton("Go Back");
        
        saveButton.setVisible(false);
        editButton.setVisible(false);
        deleteButton.setVisible(false);
        seachNowButton.setVisible(false);
        backButton.setVisible(false);
        
        addButton.addActionListener(this);
        editButton.addActionListener(this);
        deleteButton.addActionListener(this);
        exitButton.addActionListener(this);
        saveButton.addActionListener(this);
        multipleButton.addActionListener(this);
        seachNowButton.addActionListener(this);
        backButton.addActionListener(this);
        
        button_Panel.add(addButton);
        button_Panel.add(editButton);
        button_Panel.add(deleteButton);        
        button_Panel.add(saveButton);
        button_Panel.add(multipleButton);
        button_Panel.add(seachNowButton);
        button_Panel.add(backButton);
        button_Panel.add(exitButton);
               
        // Add input and button to upper panel
        upperPanel.add(button_Panel, BorderLayout.SOUTH);      
        upperPanel.add(input_Panel, BorderLayout.CENTER);
        frame.add(upperPanel);
        
        
        // Table
        int size = InformationIO.allCars.size();
        
        String[][] data = new String[size][5];
        for(int i=0; i<size; i++){
            Car c = InformationIO.allCars.get(i);
            data[i][0] = c.getCarID();
            data[i][1] = c.getModel();
            data[i][2] = c.getStatus();
            data[i][3] = ""+c.getManufactureYear();
            data[i][4] = ""+c.getRentPrice();
        }
        String[] columnNames = {"CarID", "Model", "Status", "ManufactureYear", "RentPrice" };
        tableModel = new DefaultTableModel(data, columnNames);
        table = new JTable(tableModel);
        table.setEnabled(false);
        JScrollPane sp = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, 
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        lowerPanel.add(sp);
        frame.add(lowerPanel);
        
        frame.setVisible(true);
            
    }  
}
