package carrentalsystem;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;

public class ReportPage implements ActionListener{
    public void actionPerformed(ActionEvent e){
        try {
            if (e.getSource() == gender){
                int size = InformationIO.allCustomers.size();      
                int male = 0, female = 0;
                for(int i=0; i<size; i++){
                    Customer c = InformationIO.allCustomers.get(i);
                    if (c.getGender().toString().equals("Male")){
                        male = male + 1;
                    } else if (c.getGender().toString().equals("Female")){
                        female = female + 1;
                    }
                }
                DefaultPieDataset pieDataset = new DefaultPieDataset();
                pieDataset.setValue("Male", new Integer(male));
                pieDataset.setValue("Female", new Integer(female));
                JFreeChart chart = ChartFactory.createPieChart("Gender Analysis of Customer", 
                        pieDataset, true, true, true);
                PiePlot p = (PiePlot)chart.getPlot();
                //p.setForegroundAlpha(TOP_ALIGHTMENT);
                ChartFrame cframe = new ChartFrame("Pie Chart", chart);
                cframe.setVisible(true);
                cframe.setSize(450,500);
                

            } else if (e.getSource() == carStatus){
                int size = InformationIO.allCars.size();      
                int booked = 0, available = 0, notAvailable = 0;
                for(int i=0; i<size; i++){
                    Car c = InformationIO.allCars.get(i);
                    if (c.getStatus().equals("Available")){
                        available = available + 1;
                    } else if (c.getStatus().equals("Booked")){
                        booked = booked + 1;
                    } else if (c.getStatus().equals("Not Available")){
                        notAvailable = notAvailable + 1;
                    }
                }
                DefaultPieDataset pieDataset = new DefaultPieDataset();
                pieDataset.setValue("Available Car", new Integer(available));
                pieDataset.setValue("Booked Car", new Integer(booked));
                pieDataset.setValue("Not Available", new Integer(notAvailable));
                JFreeChart chart = ChartFactory.createPieChart("Current Car Status Analysis", 
                        pieDataset, true, true, true);
                PiePlot p = (PiePlot)chart.getPlot();
                //p.setForegroundAlpha(TOP_ALIGHTMENT);
                ChartFrame cframe = new ChartFrame("Pie Chart", chart);
                cframe.setVisible(true);
                cframe.setSize(450,500);
                cframe.setLocation(1300,0);
                
                
            } else if (e.getSource() == bookingStatus){
                
                int size = InformationIO.allBookings.size();      
                int pending = 0, completed = 0;
                for(int i=0; i<size; i++){
                    Booking b = InformationIO.allBookings.get(i);
                    if (b.getStatus().equals("Pending")){
                        pending = pending + 1;
                    } else if (b.getStatus().equals("Completed")){
                        completed = completed + 1;
                    }
                }
                DefaultPieDataset pieDataset = new DefaultPieDataset();
                pieDataset.setValue("Completed Booking", new Integer(completed));
                pieDataset.setValue("Pending Booking", new Integer(pending));
                JFreeChart chart = ChartFactory.createPieChart("Current Booking Status Analysis", 
                        pieDataset, true, true, true);
                PiePlot p = (PiePlot)chart.getPlot();
                //p.setForegroundAlpha(TOP_ALIGHTMENT);
                ChartFrame cframe = new ChartFrame("Pie Chart", chart);
                cframe.setVisible(true);
                cframe.setSize(500,500);
                cframe.setLocation(0,510);
                
            } else if (e.getSource() == feedback){
                int size = InformationIO.allPayments.size();      
                int star1 = 0, star2 =0 , star3 = 0, star4 = 0, star5 = 0;
                for(int i=0; i<size; i++){
                    Payment py = InformationIO.allPayments.get(i);
                    if (py.getRating() == 1){
                        star1 = star1 + 1;
                    } else if (py.getRating() == 2){
                        star2 = star2 + 1;
                    } else if (py.getRating() == 3){
                        star3 = star3 + 1;
                    } else if (py.getRating() == 4){
                        star4 = star4 + 1;
                    } else if (py.getRating() == 5){
                        star5 = star5 + 1;
                    }
                }
                DefaultPieDataset pieDataset = new DefaultPieDataset();
                pieDataset.setValue("1 Star", new Integer(star1));
                pieDataset.setValue("2 Star", new Integer(star2));
                pieDataset.setValue("3 Star", new Integer(star3));
                pieDataset.setValue("4 Star", new Integer(star4));
                pieDataset.setValue("5 Star", new Integer(star5));
                JFreeChart chart = ChartFactory.createPieChart("Feedback Analysis", 
                        pieDataset, true, true, true);
                PiePlot p = (PiePlot)chart.getPlot();
                //p.setForegroundAlpha(TOP_ALIGHTMENT);
                ChartFrame cframe = new ChartFrame("Pie Chart", chart);
                cframe.setVisible(true);
                cframe.setSize(450,500);
                cframe.setLocation(1300,510);
            
            } else if (e.getSource() == averageFeedback){    
                AnalysisPage ratingAnalysis = new AnalysisPage();
                ratingAnalysis.setVisible(true);
                frame.setVisible(false);    
                
                
            } else if (e.getSource() == finance){    
                financeReportPage financeReport = new financeReportPage();
                financeReport.setVisible(true);
                frame.setVisible(false);
                
            } else if (e.getSource() == backButton){
                frame.setVisible(false);
                AdminHomePage home_page = new AdminHomePage(); 
                home_page.setVisible(true);
            }
        } catch (Exception ex){
            JOptionPane.showMessageDialog(frame,"Invalid");
        }
    }
    
    public JFrame getJFrame(){
        return frame;
    }
    
    private JFrame frame;
    private JButton gender, carStatus, bookingStatus, feedback, averageFeedback, 
            finance, backButton;
    
    public ReportPage(){
        frame = new JFrame("Report");
        frame.setSize(370,180); 
        frame.setLocation(700,300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        
        // Button for reports
        gender = new JButton("Gender Analysis");
        carStatus = new JButton("Car Status Analysis");
        bookingStatus = new JButton("Booking Status Analysis");
        feedback = new JButton("Feedback Analysis");
        averageFeedback = new JButton("Average Feedback Analysis");
        finance = new JButton("Finance Report");
        backButton = new JButton("Go Back");
        
        gender.addActionListener(this);
        carStatus.addActionListener(this);
        bookingStatus.addActionListener(this);
        feedback.addActionListener(this);
        averageFeedback.addActionListener(this);
        finance.addActionListener(this);
        backButton.addActionListener(this); 
        
        frame.setLayout(new FlowLayout());
        frame.add(gender);
        frame.add(carStatus);
        frame.add(bookingStatus);
        frame.add(feedback);
        frame.add(averageFeedback);
        frame.add(finance);
        frame.add(backButton);
            
        frame.setVisible(true);
    }
    
    
    
}
