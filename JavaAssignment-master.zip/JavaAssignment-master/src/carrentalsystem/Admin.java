package carrentalsystem;
public class Admin extends User{

    public Admin(String accID, String username, String password) {
        super(accID, username, password);
    }
    
}
