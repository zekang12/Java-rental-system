package carrentalsystem;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginPage implements ActionListener {
    public void actionPerformed(ActionEvent e){

        try{
            if (e.getSource() == registerButton){
                Registration register_page = new Registration();     
                register_page.setVisible(true);  //when user click register go to register page
                frame.setVisible(false);            
            
            } else if (e.getSource() == loginButton){
                String accountID = accountIDField.getText();
                String password = String.valueOf(passwordField.getPassword());
                
                if (combobox.getSelectedItem().equals("Customer")){
                    Customer found = InformationIO.checkAccID(accountID);
                    if (found != null){
                        if (password.equals(found.getPassword())){
                            CarRentalSystem.loginUser = found;
                            frame.setVisible(false);
                            //JOptionPane.showMessageDialog(frame, "Successful");
                            CusHomePage home_page = new CusHomePage();
                            home_page.setVisible(true);
                        } else{
                            throw new Exception();
                        }
                    } else {
                        throw new Exception();
                    }
                // When combobox select Admin
                } else {
                    Admin found = InformationIO.checkAdminAccID(accountID);
                    if (found != null){
                        if (password.equals(found.getPassword())){
                            CarRentalSystem.loginAdmin = found;
                            if (accountID.equals("SUP0001") && password.equals("123")){                               
                                superAdminHomePage home_page = new superAdminHomePage();
                                home_page.getJFrame().setVisible(true);
                            } else {
                                //JOptionPane.showMessageDialog(frame, "Successful");
                                AdminHomePage home_page = new AdminHomePage();
                                home_page.setVisible(true);
                            }
                            frame.setVisible(false);                           
                        } else{
                            throw new Exception();
                        }
                    } else {
                        throw new Exception();
                    }                    
                }
            
            } else if (e.getSource() == exitButton){
                InformationIO.writeToCusFile();
                InformationIO.writeToBookingFile();
                InformationIO.writeToCarFile();
                InformationIO.writeToAdminFile();
                InformationIO.writeToPaymentFile();
                System.exit(0);
            }
         
        } catch(Exception ex){
            JOptionPane.showMessageDialog(frame, "Invalid input");
        }            
    }
    
    public JFrame getJFrame(){
        return frame;
    }
    
    private JFrame frame;
    //private Border border;
    private JPanel panel, headerPanel, buttonPanel;
    private JLabel accountIDLabel, passwordLabel, headerLabel, usertypeLabel;
    private JButton loginButton, registerButton, exitButton;
    private JTextField accountIDField;
    private JPasswordField passwordField;
    private Font titleFont, subtitleFont;
    private JComboBox combobox;
    
    
    public LoginPage(){
        frame = new JFrame("Login Page");
        frame.setSize(500,350);
        frame.setLocation(700,300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        
        // border and font 
        //border = BorderFactory.createLineBorder(Color.BLUE,1);
        titleFont = new Font(null, Font.BOLD, 24);
        subtitleFont = new Font(null, Font.BOLD, 16);
        
        // Panel
        panel = new JPanel();
        frame.add(panel);              
        panel.setLayout(null);
        
        // hearder
        headerPanel = new JPanel();
        headerPanel.setBackground(Color.GRAY);
        headerLabel = new JLabel("*Car Rental System*");
        headerLabel.setFont(titleFont);
        headerLabel.setForeground(Color.white);
        headerPanel.add(headerLabel);
        frame.add(headerPanel, BorderLayout.NORTH);
        
        
        //Label
        accountIDLabel = new JLabel("Account ID: ");
        passwordLabel = new JLabel("Password: ");
        usertypeLabel = new JLabel("User Type: ");

        accountIDLabel.setBounds(100,50,100,25); //(x-axis, y-axis, width, height)
        passwordLabel.setBounds(100,100,100,25);
        usertypeLabel.setBounds(100,150,100,25);
              
        accountIDLabel.setFont(subtitleFont);
        passwordLabel.setFont(subtitleFont);
        usertypeLabel.setFont(subtitleFont);
        
        panel.add(accountIDLabel);
        panel.add(passwordLabel);
        panel.add(usertypeLabel);
        
        // Text Field
        accountIDField = new JTextField(10);
        passwordField = new JPasswordField(10);
        accountIDField.setBounds(200,50,150,25);
        passwordField.setBounds(200,100,150,25);
        
        panel.add(accountIDField);
        panel.add(passwordField);
        
        // ComboBox
        String [] usertype = {"Customer", "Admin"};
        combobox = new JComboBox(usertype);
        combobox.setBounds(200,150,150,25);
        //combobox.addActionListener(this);
        panel.add(combobox);
        
        // Button
        buttonPanel = new JPanel();
             
        loginButton = new JButton("Login");
        registerButton = new JButton("Register");
        exitButton = new JButton("Exit");
        
        loginButton.addActionListener(this);
        registerButton.addActionListener(this);
        exitButton.addActionListener(this);
        
        buttonPanel.add(loginButton);
        buttonPanel.add(registerButton);
        buttonPanel.add(exitButton);
                
        frame.add(buttonPanel, BorderLayout.SOUTH);
        
        frame.setVisible(true);
        
    }   
}
